#include <stdio.h>

int main() {
    printf("Hello, Debian package!\n");
    return 0;
}
